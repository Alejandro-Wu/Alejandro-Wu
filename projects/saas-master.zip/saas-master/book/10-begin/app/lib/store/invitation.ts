class Invitation {
  public _id: string;
  public teamId: string;
  public email: string;
  public createdAt: Date;

  constructor(params) {
    Object.assign(this, params);
  }
}

export { Invitation };
