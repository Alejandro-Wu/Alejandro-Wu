module.exports = {
  poweredByHeader: false,
  webpack5: true,
  typescript: {
    ignoreBuildErrors: true,
  },
};
