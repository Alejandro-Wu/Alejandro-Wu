const a = 'someString';

// some comment

export default a;
