module.exports = {
  poweredByHeader: false,
  typescript: {
    ignoreBuildErrors: true,
  },
};
