import * as Types from '@prisma/client'

export { Types }
