'use client'

export { SessionProvider as default } from 'next-auth/react'
