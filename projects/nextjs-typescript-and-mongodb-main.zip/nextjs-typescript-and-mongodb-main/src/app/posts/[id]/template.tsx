export { default } from '@/components/animated-template'
