/**
 * @type { import("next").NextConfig }
 */
module.exports = {
  reactStrictMode: false
}
