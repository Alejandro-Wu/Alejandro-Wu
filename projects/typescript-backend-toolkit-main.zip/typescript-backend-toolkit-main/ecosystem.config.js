module.exports = {
  apps: [
    {
      name: 'typescript-backend-toolkit',
      script: './dist/main.js',
    },
  ],
};
