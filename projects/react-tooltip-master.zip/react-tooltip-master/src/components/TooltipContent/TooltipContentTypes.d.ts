export interface ITooltipContent {
  content: string
}
